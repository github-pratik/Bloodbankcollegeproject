/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project;
import java.sql.*;
import javax.swing.JOptionPane;
/**
 *
 * @author Prartik
 */
public class ConnectionProvider {
    
    public static Connection getCon(){
        Connection con= null;
        String url = "jdbc:mysql://localhost:3306/bbms";
        String username = "root";
        String password = "Pratikpatil@28";
    try{
        Class.forName("com.mysql.jdbc.Driver");
        con= DriverManager.getConnection(url,username,password);
        System.out.println("Database Connected.");
    }
    catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Database Connection Failed.");
            System.out.println("Database.ConnectDB():" + e);
        }
    return con;
    }
    
}
